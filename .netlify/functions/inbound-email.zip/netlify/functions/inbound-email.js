var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var inbound_email_exports = {};
__export(inbound_email_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(inbound_email_exports);
var import_functions = require("@netlify/functions");
var import_app = require("firebase-admin/app");
var import_firestore = require("firebase-admin/firestore");
var import_nodemailer = __toESM(require("nodemailer"), 1);
if (!(0, import_app.getApps)().length) {
  (0, import_app.initializeApp)({
    credential: (0, import_app.cert)({
      projectId: process.env.FIREBASE_PROJECT_ID,
      clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
      privateKey: process.env.FIREBASE_PRIVATE_KEY.replace(/\\n/g, "\n")
    })
  });
}
const db = (0, import_firestore.getFirestore)();
const transporter = import_nodemailer.default.createTransport({
  service: "gmail",
  auth: {
    user: process.env.GMAIL_USER,
    pass: process.env.GMAIL_APP_PASSWORD
  }
});
async function handler(event) {
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      body: "Method Not Allowed"
    };
  }
  try {
    const payload = JSON.parse(event.body);
    const {
      from,
      subject,
      text,
      html,
      attachments = []
    } = payload;
    const emailRef = db.collection("inbound_emails").doc();
    await emailRef.set({
      from_email: from,
      subject,
      text_content: text,
      html_content: html,
      has_attachments: attachments.length > 0,
      processed: false,
      received_at: (/* @__PURE__ */ new Date()).toISOString(),
      created_at: (/* @__PURE__ */ new Date()).toISOString(),
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    });
    await forwardToAdmin(payload);
    return {
      statusCode: 200,
      body: JSON.stringify({ message: "Email processed successfully" })
    };
  } catch (error) {
    console.error("Error processing email:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Internal server error" })
    };
  }
}
async function forwardToAdmin(emailData) {
  try {
    const attachmentsHtml = emailData.attachments?.length ? `<p><strong>Attachments:</strong> ${emailData.attachments.map((a) => a.filename).join(", ")}</p>` : "";
    const mailOptions = {
      from: process.env.GMAIL_USER,
      to: "BexleyCohen@gmail.com",
      subject: `[SPENDLOCAL] ${emailData.subject}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #2563eb;">New SPENDLOCAL Email</h2>
          <div style="background: #f3f4f6; padding: 15px; border-radius: 8px; margin: 15px 0;">
            <p><strong>From:</strong> ${emailData.from}</p>
            <p><strong>Subject:</strong> ${emailData.subject}</p>
            <p><strong>Received:</strong> ${(/* @__PURE__ */ new Date()).toLocaleString()}</p>
            ${attachmentsHtml}
          </div>
          <hr style="border: 1px solid #e5e7eb; margin: 20px 0;">
          <div style="background: white; padding: 15px; border-radius: 8px; border: 1px solid #e5e7eb;">
            ${emailData.html || emailData.text}
          </div>
        </div>
      `,
      attachments: emailData.attachments
    };
    await transporter.sendMail(mailOptions);
  } catch (error) {
    console.error("Error forwarding email:", error);
    throw error;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
